function cadastrar() {
    return "Cadastro de Cliente";
}

function buscar() {
    return "Lista de Clientes";
}

module.exports = {
    buscar,
    cadastrar,
};

