function cadastrar() {
    return "Cadastro de Categoria";
}

function buscar() {
    return "Lista de Categorias";
}

module.exports = {
    buscar,
    cadastrar,
};

