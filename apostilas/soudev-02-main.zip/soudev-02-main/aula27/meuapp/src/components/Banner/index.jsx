import React from 'react';
import './banner.css';

export default function Banner()
{
    return(
        <>
            <section id="banner">
                Banner
            </section>
        </>
    );
}

