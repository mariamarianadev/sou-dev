function cadastro() {
    return "Pagina de Cadastro";
}
