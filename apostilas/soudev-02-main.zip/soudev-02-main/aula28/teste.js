let alunas = ['rebeca', 'andy', 'carly', 'outra rebeca'];



alunas = alunas.map(x => x.toUpperCase());

console.log('-------------');

console.log(alunas[0]);
console.log(alunas[3]);
