import React from 'react';
import Ways from './routes/Ways';

export default function App()
{
  return(
    <>
      <Ways />
    </>
  );

}
