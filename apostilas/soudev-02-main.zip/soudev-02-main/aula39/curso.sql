INSERT INTO tb_curso
    (nome, carga_horaria, descricao)
VALUES 
    ('FullStack', '192', 'Curso de desenvolvimento web com JS');

INSERT INTO tb_curso
    (nome, carga_horaria, descricao)
VALUES 
    ('PHP', '88', 'Curso de desenvolvimento de API');

INSERT INTO tb_curso
    (nome, carga_horaria, descricao)
VALUES 
    ('Marketing', '192', 'Curso de marketing e outras coisas coachianas');


