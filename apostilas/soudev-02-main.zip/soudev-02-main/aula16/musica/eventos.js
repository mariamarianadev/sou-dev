//inicio
let numero = 1;

while (numero <= 10) { //condição de término

    document.write("Carro pancadão hey <br>");

    numero = numero + 1; //passo / meio de transporte / incremento/decremento
}

document.write("<hr>");

let n = 1;

while (n <= 5) {
    document.write("<br> Agora na velocidade: " + n);

    document.write("<br> Creu creu creu creu <br>");

    n = n + 1;
}



