let numero = 1;

while (numero <= 100) {
    if (numero % 2 == 0) { 
        //se entrar nesse IF é pq é par
        document.write(numero + "<br>");
    }

    // numero = numero + 1;
    // numero += 1;
    numero++;
}

document.write("<hr>");

let x = 100;

while (x >= 1) {
    document.write(x + "<br>");
    x--;
}

