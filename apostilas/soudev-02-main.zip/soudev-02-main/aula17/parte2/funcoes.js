function add() {
    conteudo.innerHTML = "Pagina de Cadastro";
}

function list() {
    conteudo.innerHTML = "Pagina de listar";
}

function report() {
    conteudo.innerHTML = "Pagina de Relatorios";
}

