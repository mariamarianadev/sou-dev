let nome = 'Carol';
nome = 'Lane';
nome = 'Marilia';

let numero  = 10; //int 

let saldo = -899.76; //float

let status = false; //boolean

console.log(nome);
