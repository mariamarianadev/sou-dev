export default function MeusPedidos() {
    return (
        <div>
            Pagina de Meus Pedidos
        </div>
    )
}
