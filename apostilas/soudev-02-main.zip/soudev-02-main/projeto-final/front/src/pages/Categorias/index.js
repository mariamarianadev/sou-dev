export default function Categorias() {
    return (
        <div>
            Pagina de Categorias
        </div>
    )
}
