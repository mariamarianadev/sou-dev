import { Container } from "@mui/material";

export default function Footer() {
    return (
        <>
            <footer style={{backgroundColor: "#333", color: "white"}}>
                <Container>
                    Footer
                </Container>
            </footer>
        </>
    )
}
