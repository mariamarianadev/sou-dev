export default function ColecoesDestaque() {
    return (
        <div>
            Colecoes em Destaque
        </div>
    )
}
