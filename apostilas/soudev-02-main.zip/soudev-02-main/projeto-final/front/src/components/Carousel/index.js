export default function Carousel() {
    return (
        <div>
            Carousel
        </div>
    )
}
