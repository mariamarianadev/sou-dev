const categorias = [
    {
        id: 1,
        nome: "categoria 1",
        status: 1
    },
    {
        id: 2,
        nome: "categoria 2",
        status: 1
    },
    {
        id: 3,
        nome: "categoria 3",
        status: 3
    },
];
module.exports = categorias;
