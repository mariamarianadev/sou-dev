const produtos = [
    {
        id: 1,
        nome: 'Saia'
    },
    {
        id: 2,
        nome: 'Boné'
    }
];
 module.exports = produtos;
